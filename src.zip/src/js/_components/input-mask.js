// ========= In p u t   t e l e p h o n e   m a s k ===========
$("input[type=tel]").inputmask({"mask": "+38 (999) 999-9999","clearIncomplete": false});
// ========= =========== =========== ===========